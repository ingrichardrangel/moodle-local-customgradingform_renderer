<?php

$string['pluginname'] = 'Importador de rúbricas desde CSV';
$string['importfromcsv'] = 'Importar rúbrica desde CSV';
$string['choosecsvfile'] = 'Seleccione el archivo CSV';
$string['submitcsv'] = 'Importar rúbrica';
$string['csvrequired'] = 'Debe seleccionar un archivo CSV válido.';
$string['importsuccess'] = 'Rúbrica importada con éxito.';
$string['importerror'] = 'Ocurrió un error al importar la rúbrica.';

// Validación de máximo
$string['maxlevelscore'] = 'Puntaje máximo por nivel';
$string['maxlevelscore_desc'] = 'Define el puntaje máximo permitido para cada nivel de evaluación dentro de un criterio. Si algún nivel en el archivo CSV supera este valor, se mostrará un error al intentar importar.';
$string['enablemaxlevelscore'] = 'Habilitar validación de puntaje máximo';
$string['enablemaxlevelscore_desc'] = 'Si se habilita, se validará que ningún nivel exceda el valor máximo permitido.';
// Validación de mínimo
$string['enableminlevelscore'] = 'Habilitar validación de puntaje mínimo';
$string['enableminlevelscore_desc'] = 'Si se habilita, se validará que ningún nivel tenga un valor menor al mínimo permitido.';
$string['minlevelscore'] = 'Puntaje mínimo por nivel';
$string['minlevelscore_desc'] = 'Valor mínimo permitido para cada nivel. Generalmente debe ser 0.';
